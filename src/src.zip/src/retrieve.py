""" Retrieves and stores all the necessary data """


from votes import get_voting_record
from hansard import get_speeches


get_voting_record()
get_speeches()
